// ============================================================
// Trip — Client Script
// UVTech TMS | Frappe v16
// ============================================================

frappe.ui.form.on('Trip', {

    // --------------------------------------------------------
    // SETUP & REFRESH
    // --------------------------------------------------------

    setup(frm) {
        // City → State auto-fill on all city fields
        ['origin_city_1', 'origin_city_2', 'destination_city_1', 'destination_city_2'].forEach(f => {
            frm.set_query(f, () => ({ filters: { is_active: 1 } }));
        });
    },

    refresh(frm) {
        _applyTripTypeTheme(frm);
        _setFieldVisibility(frm);
        _setReadOnlyRules(frm);

        if (!frm.is_new()) {
            _addStatusButton(frm);
        }

        // Show trip status as colored indicator
        const statusColors = {
            'Trip Created':    'blue',
            'In Transit':      'orange',
            'Awaiting Billing':'yellow',
            'Billed':          'green',
            'Payment Received':'purple',
            'Closed':          'darkgrey',
        };
        const color = statusColors[frm.doc.trip_status] || 'grey';
        frm.page.set_indicator(__(frm.doc.trip_status), color);
    },

    // --------------------------------------------------------
    // TRIP TYPE — drives visibility + theme
    // --------------------------------------------------------

    trip_type(frm) {
        _applyTripTypeTheme(frm);
        _setFieldVisibility(frm);
        frm.refresh_fields();
    },

    // --------------------------------------------------------
    // CITY → STATE AUTO-FILL
    // --------------------------------------------------------

    origin_city_1(frm) { _fetchState(frm, 'origin_city_1', 'origin_state_1'); },
    origin_city_2(frm) { _fetchState(frm, 'origin_city_2', 'origin_state_2'); },
    destination_city_1(frm) { _fetchState(frm, 'destination_city_1', 'destination_state_1'); },
    destination_city_2(frm) { _fetchState(frm, 'destination_city_2', 'destination_state_2'); },

    // --------------------------------------------------------
    // LOADING DETENTION LIVE CALC
    // --------------------------------------------------------

    reach_date_time(frm)               { _calcLoadingDetention(frm); },
    dispatch_date_time(frm)            { _calcLoadingDetention(frm); _calcActualJourneyTime(frm); },
    loading_detention_rate_per_day(frm){ _calcLoadingDetention(frm); },

    // --------------------------------------------------------
    // UNLOADING DETENTION LIVE CALC
    // --------------------------------------------------------

    arrival_date_time(frm)              { _calcUnloadingDetention(frm); _calcActualJourneyTime(frm); },
    release_date_time(frm)              { _calcUnloadingDetention(frm); },
    unloading_detention_rate_per_day(frm){ _calcUnloadingDetention(frm); },

    // --------------------------------------------------------
    // VENDOR FREIGHT
    // --------------------------------------------------------

    vendor_freight(frm)      { _calcVendorFreight(frm); },
    vendor_freight_extra(frm){ _calcVendorFreight(frm); },

    // --------------------------------------------------------
    // LOADING / UNLOADING CHARGES
    // --------------------------------------------------------

    loading_charge(frm)  { _calcLoadingUnloadingTotal(frm); _calcTotalAdditional(frm); },
    unloading_charge(frm){ _calcLoadingUnloadingTotal(frm); _calcTotalAdditional(frm); },
    weighment_charges(frm){ _calcTotalAdditional(frm); },

    // --------------------------------------------------------
    // DEDICATED KM
    // --------------------------------------------------------

    start_km(frm)   { _calcDedicatedKm(frm); },
    end_km(frm)     { _calcDedicatedKm(frm); },
    standard_km(frm){ _calcDedicatedKm(frm); },

    // --------------------------------------------------------
    // APPROVED CHARGES
    // --------------------------------------------------------

    approved_origin_detention(frm)     { _calcApproved(frm); },
    approved_destination_detention(frm){ _calcApproved(frm); },
    approved_loading_charge(frm)       { _calcApproved(frm); },
    approved_unloading_charge(frm)     { _calcApproved(frm); },
    approved_weighment(frm)            { _calcApproved(frm); },
    approved_extra_expenses(frm)       { _calcApproved(frm); },
    tds_by_customer(frm)               { _calcApproved(frm); },

    // --------------------------------------------------------
    // CUSTOMER FREIGHT
    // --------------------------------------------------------

    customer_freight(frm){ _calcTripTotal(frm); },

    // --------------------------------------------------------
    // POD
    // --------------------------------------------------------

    pod_upload_date(frm){ _updatePodStatus(frm); },
    pod_type(frm)       { _updatePodStatus(frm); },
});


// ============================================================
// HELPERS
// ============================================================

function _fetchState(frm, cityField, stateField) {
    const city = frm.doc[cityField];
    if (!city) {
        frm.set_value(stateField, '');
        return;
    }
    frappe.db.get_value('TMS City', city, 'state', (r) => {
        frm.set_value(stateField, r && r.state ? r.state : '');
    });
}

function _setFieldVisibility(frm) {
    const t = frm.doc.trip_type || '';
    const isPrimary    = ['Primary Trip', 'RR Primary', 'RCPL Primary'].includes(t);
    const isSecondary  = t.includes('Secondary');
    const isDedicated  = t === 'Secondary Dedicated';
    const isOther      = t === 'Other';
    const isMarket     = ['Primary Trip', 'Secondary Market', 'RR Primary', 'RCPL Primary'].includes(t);

    frm.toggle_display('section_dedicated_km', isDedicated);
    frm.toggle_display('section_vendor_commercials', isMarket);
    frm.toggle_display('section_other_trip_billing', isOther);

    // Indent / SO fields
    frm.toggle_display('indent_date', isPrimary);
    frm.toggle_display('indent_no', isPrimary);
    frm.toggle_display('so_no', t === 'RCPL Primary');

    // Billing dates
    frm.toggle_display('section_billing_dates', isPrimary || isSecondary);
}

function _setReadOnlyRules(frm) {
    // Customer freight locked after first save
    if (!frm.is_new()) {
        frm.set_df_property('customer_freight', 'read_only', 1);
    }
}

function _applyTripTypeTheme(frm) {
    const company = frappe.defaults.get_user_default('Company');
    if (!company) return;

    frappe.call({
        method: 'uvtech_tms.api.get_trip_type_theme',
        args: { company: company, trip_type: frm.doc.trip_type },
        callback(r) {
            if (!r.message) return;
            const { color, theme } = r.message;
            if (!color) return;

            // Apply color to form header strip
            const strip = frm.page.wrapper.find('.page-head');
            const isDark = _isDarkColor(color);
            const textColor = isDark ? '#fff' : '#1a1a1a';

            strip.css({
                'border-top': `4px solid ${color}`,
                'background': _lightenColor(color, theme === 'Dark' ? 0.1 : 0.92),
            });

            // Color the Trip Type field label
            const tripTypeLabel = frm.get_field('trip_type').$wrapper
                .find('.control-label');
            tripTypeLabel.css({ 'color': color, 'font-weight': '600' });

            // Badge next to title
            const existing = frm.page.wrapper.find('.tms-type-badge');
            if (existing.length) existing.remove();

            const badge = $(`
                <span class="tms-type-badge" style="
                    background: ${color};
                    color: ${textColor};
                    border-radius: 4px;
                    padding: 2px 10px;
                    font-size: 12px;
                    font-weight: 600;
                    margin-left: 10px;
                    vertical-align: middle;
                ">${frm.doc.trip_type || ''}</span>
            `);
            frm.page.wrapper.find('.title-text').after(badge);
        }
    });
}

function _isDarkColor(hex) {
    if (!hex) return false;
    const c = hex.replace('#', '');
    const r = parseInt(c.substr(0, 2), 16);
    const g = parseInt(c.substr(2, 2), 16);
    const b = parseInt(c.substr(4, 2), 16);
    return (r * 299 + g * 587 + b * 114) / 1000 < 128;
}

function _lightenColor(hex, factor) {
    if (!hex) return '#f5f5f5';
    const c = hex.replace('#', '');
    const r = Math.round(parseInt(c.substr(0, 2), 16) + (255 - parseInt(c.substr(0, 2), 16)) * factor);
    const g = Math.round(parseInt(c.substr(2, 2), 16) + (255 - parseInt(c.substr(2, 2), 16)) * factor);
    const b = Math.round(parseInt(c.substr(4, 2), 16) + (255 - parseInt(c.substr(4, 2), 16)) * factor);
    return `rgb(${r},${g},${b})`;
}

// ---- DETENTION ----

function _timeDiffHours(dt1, dt2) {
    if (!dt1 || !dt2) return 0;
    const d1 = new Date(dt1), d2 = new Date(dt2);
    return Math.max(0, (d1 - d2) / 3600000);
}

function _detentionDays(hours) {
    if (hours <= 24) return 0;
    return Math.round(((hours - 24) / 24) * 100) / 100;
}

function _calcLoadingDetention(frm) {
    const hours = _timeDiffHours(frm.doc.dispatch_date_time, frm.doc.reach_date_time);
    const days = _detentionDays(hours);
    const rate = flt(frm.doc.loading_detention_rate_per_day);
    frm.set_value('loading_detention_days', days);
    frm.set_value('loading_detention_amount', Math.round(days * rate * 100) / 100);
    _calcTotalDetention(frm);
    _calcTotalAdditional(frm);
}

function _calcUnloadingDetention(frm) {
    const hours = _timeDiffHours(frm.doc.release_date_time, frm.doc.arrival_date_time);
    const days = _detentionDays(hours);
    const rate = flt(frm.doc.unloading_detention_rate_per_day);
    frm.set_value('unloading_detention_days', days);
    frm.set_value('unloading_detention_amount', Math.round(days * rate * 100) / 100);
    _calcTotalDetention(frm);
    _calcTotalAdditional(frm);
}

function _calcTotalDetention(frm) {
    frm.set_value('total_detention_days',
        flt(frm.doc.loading_detention_days) + flt(frm.doc.unloading_detention_days));
    frm.set_value('total_detention_amount',
        flt(frm.doc.loading_detention_amount) + flt(frm.doc.unloading_detention_amount));
}

function _calcActualJourneyTime(frm) {
    const hours = _timeDiffHours(frm.doc.arrival_date_time, frm.doc.dispatch_date_time);
    frm.set_value('actual_journey_time', Math.round(hours * 100) / 100);
}

// ---- VENDOR ----

function _calcVendorFreight(frm) {
    frm.set_value('total_vendor_freight',
        flt(frm.doc.vendor_freight) + flt(frm.doc.vendor_freight_extra));
}

// ---- LOADING/UNLOADING ----

function _calcLoadingUnloadingTotal(frm) {
    frm.set_value('total_loading_unloading',
        flt(frm.doc.loading_charge) + flt(frm.doc.unloading_charge));
}

// ---- ADDITIONAL CHARGES ----

function _calcTotalAdditional(frm) {
    frm.set_value('total_additional_charges',
        flt(frm.doc.total_detention_amount)
        + flt(frm.doc.total_loading_unloading)
        + flt(frm.doc.weighment_charges));
    _calcApproved(frm);
}

// ---- DEDICATED KM ----

function _calcDedicatedKm(frm) {
    const total = flt(frm.doc.end_km) - flt(frm.doc.start_km);
    frm.set_value('total_km', Math.round(total * 100) / 100);
    frm.set_value('variation', Math.round((total - flt(frm.doc.standard_km)) * 100) / 100);
}

// ---- APPROVED ----

function _calcApproved(frm) {
    const det   = flt(frm.doc.approved_origin_detention) + flt(frm.doc.approved_destination_detention);
    const lu    = flt(frm.doc.approved_loading_charge) + flt(frm.doc.approved_unloading_charge);
    const total = det + lu + flt(frm.doc.approved_weighment) + flt(frm.doc.approved_extra_expenses)
                  - flt(frm.doc.tds_by_customer);

    frm.set_value('approved_detention_charge', Math.round(det * 100) / 100);
    frm.set_value('approved_loading_unloading', Math.round(lu * 100) / 100);
    frm.set_value('total_approved_additional', Math.round(total * 100) / 100);
    frm.set_value('difference_claimed_approved',
        Math.round((flt(frm.doc.total_additional_charges) - total) * 100) / 100);
    _calcTripTotal(frm);
}

// ---- TRIP TOTAL ----

function _calcTripTotal(frm) {
    frm.set_value('trip_total_amount',
        flt(frm.doc.customer_freight) + flt(frm.doc.total_approved_additional));
}

// ---- POD STATUS ----

function _updatePodStatus(frm) {
    const status = (frm.doc.pod_upload_date && frm.doc.pod_type)
        ? 'POD Uploaded'
        : 'POD Not Uploaded';
    frm.set_value('pod_status', status);
}

// ---- STATUS BUTTON ----

function _addStatusButton(frm) {
    if (frm.doc.trip_status === 'Payment Received' && frm.doc.trip_total_billed && frm.doc.utr_no) {
        frm.add_custom_button(__('Close Trip'), () => {
            frappe.confirm(
                __('Mark this trip as Closed?'),
                () => {
                    frm.set_value('trip_status', 'Closed');
                    frm.save();
                }
            );
        }, __('Actions')).addClass('btn-success');
    }
}

// ---- UTILITY ----

function flt(v) {
    return parseFloat(v) || 0;
}
