import frappe
from frappe.model.document import Document


class VendorPayment(Document):
    pass
