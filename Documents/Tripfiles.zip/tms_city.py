import frappe
from frappe.model.document import Document


class TMSCity(Document):
    def validate(self):
        self.city_name = self.city_name.strip().title()
        self.state = self.state.strip().title()
