import frappe
from frappe.model.document import Document


class TMSSettings(Document):
    def validate(self):
        self._validate_company_code()
        self._validate_single_default()
        self._ensure_default_trip_type_has_theme()

    def _validate_company_code(self):
        if self.company_code:
            self.company_code = self.company_code.upper().strip()
            if not self.company_code.isalnum():
                frappe.throw(frappe._("Company Code must be alphanumeric (letters and numbers only)."))

    def _validate_single_default(self):
        defaults = [row for row in self.trip_type_themes if row.is_default]
        if len(defaults) > 1:
            frappe.throw(frappe._("Only one Trip Type can be marked as Default."))

    def _ensure_default_trip_type_has_theme(self):
        """Warn if default_trip_type has no matching theme row."""
        if not self.default_trip_type:
            return
        types = [row.trip_type for row in self.trip_type_themes]
        if self.default_trip_type not in types:
            frappe.msgprint(
                frappe._(
                    "Default Trip Type '{0}' does not have a color/theme defined in the table below. "
                    "Please add it."
                ).format(self.default_trip_type),
                indicator="orange",
                alert=True,
            )
