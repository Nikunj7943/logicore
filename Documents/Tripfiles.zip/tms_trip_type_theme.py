import frappe
from frappe.model.document import Document


class TMSTripTypeTheme(Document):
    pass
