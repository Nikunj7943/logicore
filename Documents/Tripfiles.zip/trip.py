import frappe
from frappe.model.document import Document
from frappe.utils import (
    flt, cint, now_datetime, get_datetime, date_diff,
    time_diff_in_hours, getdate, nowdate
)


class Trip(Document):

    # ------------------------------------------------------------------ #
    #  NAMING                                                              #
    # ------------------------------------------------------------------ #

    def autoname(self):
        """
        Build Trip ID: {COMPANY_CODE}{TYPE_CODE}-{FISCAL_YEAR}-{SEQ:05d}
        Example: SLPLP-2526-00001
        Type codes: P=RR Primary / Primary Trip, R=RCPL Primary,
                    D=Dedicated/Secondary Dedicated, S=Secondary Market,
                    O=Other
        """
        company = frappe.defaults.get_user_default("Company") or frappe.db.get_single_value(
            "Global Defaults", "default_company"
        )
        company_code = self._get_company_code(company)
        type_code = self._get_trip_type_code()
        fiscal_prefix = self._get_fiscal_prefix()

        series_key = f"TMS-TRIP-{company_code}{type_code}-{fiscal_prefix}"
        seq = frappe.db.get_value("Series", series_key, "current") or 0
        seq += 1
        frappe.db.set_value("Series", series_key, "current", seq, update_modified=False)

        self.name = f"{company_code}{type_code}-{fiscal_prefix}-{str(seq).zfill(5)}"

    def _get_company_code(self, company):
        if not company:
            return "TMS"
        # Try TMS Settings first
        settings = self._get_tms_settings(company)
        if settings and settings.get("company_code"):
            return settings["company_code"].upper()
        # Fallback to Company abbreviation
        abbr = frappe.db.get_value("Company", company, "abbr") or "TMS"
        return abbr.upper()

    def _get_trip_type_code(self):
        mapping = {
            "Primary Trip": "P",
            "RR Primary": "P",
            "RCPL Primary": "R",
            "Secondary Dedicated": "D",
            "Dedicated": "D",
            "Secondary Market": "S",
            "Secondary": "S",
            "Other": "O",
        }
        return mapping.get(self.trip_type, "X")

    def _get_fiscal_prefix(self):
        """Returns YYMM-style fiscal prefix, e.g. '2526' for FY 2025-26."""
        trip_date = getdate(self.trip_date) if self.trip_date else getdate(nowdate())
        year = trip_date.year
        month = trip_date.month
        if month >= 4:
            fy_start = year
        else:
            fy_start = year - 1
        fy_end = fy_start + 1
        return f"{str(fy_start)[2:]}{str(fy_end)[2:]}"

    def _get_tms_settings(self, company=None):
        try:
            settings = frappe.get_single("TMS Settings")
            return settings.as_dict()
        except Exception:
            return {}

    # ------------------------------------------------------------------ #
    #  VALIDATE                                                            #
    # ------------------------------------------------------------------ #

    def validate(self):
        self._derive_states()
        self._calc_detention_loading()
        self._calc_detention_unloading()
        self._calc_journey_times()
        self._calc_dedicated_km()
        self._calc_vendor_freight()
        self._calc_loading_unloading_totals()
        self._calc_total_additional_charges()
        self._calc_approved_charges()
        self._calc_trip_total()
        self._update_pod_status()
        self._update_trip_status()

    # ------------------------------------------------------------------ #
    #  STATE AUTO-FILL                                                     #
    # ------------------------------------------------------------------ #

    def _derive_states(self):
        for city_field, state_field in [
            ("origin_city_1", "origin_state_1"),
            ("origin_city_2", "origin_state_2"),
            ("destination_city_1", "destination_state_1"),
            ("destination_city_2", "destination_state_2"),
        ]:
            city = self.get(city_field)
            if city:
                state = frappe.db.get_value("TMS City", city, "state")
                self.set(state_field, state or "")
            else:
                self.set(state_field, "")

    # ------------------------------------------------------------------ #
    #  DETENTION CALCULATIONS                                              #
    # ------------------------------------------------------------------ #

    def _calc_detention_loading(self):
        """
        Loading detention: hours vehicle spent at loading site beyond 24h.
        Every 24h after first 24h = 1 detention day.
        """
        if not (self.reach_date_time and self.dispatch_date_time):
            self.loading_detention_days = 0
            self.loading_detention_amount = 0
            return

        hours = time_diff_in_hours(self.dispatch_date_time, self.reach_date_time)
        if hours <= 0:
            self.loading_detention_days = 0
        elif hours <= 24:
            self.loading_detention_days = 0
        else:
            self.loading_detention_days = flt((hours - 24) / 24, 2)

        self.loading_detention_amount = flt(
            self.loading_detention_days * flt(self.loading_detention_rate_per_day), 2
        )

    def _calc_detention_unloading(self):
        """
        Unloading detention: hours beyond 24h at unloading site.
        """
        if not (self.arrival_date_time and self.release_date_time):
            self.unloading_detention_days = 0
            self.unloading_detention_amount = 0
        else:
            hours = time_diff_in_hours(self.release_date_time, self.arrival_date_time)
            if hours <= 24:
                self.unloading_detention_days = 0
            else:
                self.unloading_detention_days = flt((hours - 24) / 24, 2)

            self.unloading_detention_amount = flt(
                self.unloading_detention_days * flt(self.unloading_detention_rate_per_day), 2
            )

        self.total_detention_days = flt(
            flt(self.loading_detention_days) + flt(self.unloading_detention_days), 2
        )
        self.total_detention_amount = flt(
            flt(self.loading_detention_amount) + flt(self.unloading_detention_amount), 2
        )

    # ------------------------------------------------------------------ #
    #  JOURNEY TIME                                                        #
    # ------------------------------------------------------------------ #

    def _calc_journey_times(self):
        """
        Ideal journey time: distance / (400 km/day * 24h/day) in hours.
        Actual journey time: dispatch → arrival.
        """
        if flt(self.distance_km) > 0:
            self.journey_time_ideal = flt(flt(self.distance_km) / (400 / 24), 2)
        else:
            self.journey_time_ideal = 0

        if self.dispatch_date_time and self.arrival_date_time:
            self.actual_journey_time = flt(
                time_diff_in_hours(self.arrival_date_time, self.dispatch_date_time), 2
            )
        else:
            self.actual_journey_time = 0

    # ------------------------------------------------------------------ #
    #  DEDICATED KM                                                        #
    # ------------------------------------------------------------------ #

    def _calc_dedicated_km(self):
        if self.trip_type != "Secondary Dedicated":
            return
        self.total_km = flt(flt(self.end_km) - flt(self.start_km), 2)
        self.variation = flt(flt(self.total_km) - flt(self.standard_km), 2)

    # ------------------------------------------------------------------ #
    #  VENDOR FREIGHT                                                      #
    # ------------------------------------------------------------------ #

    def _calc_vendor_freight(self):
        self.total_vendor_freight = flt(
            flt(self.vendor_freight) + flt(self.vendor_freight_extra), 2
        )

    # ------------------------------------------------------------------ #
    #  LOADING / UNLOADING TOTALS                                          #
    # ------------------------------------------------------------------ #

    def _calc_loading_unloading_totals(self):
        self.total_loading_unloading = flt(
            flt(self.loading_charge) + flt(self.unloading_charge), 2
        )

    # ------------------------------------------------------------------ #
    #  TOTAL ADDITIONAL CHARGES                                            #
    # ------------------------------------------------------------------ #

    def _calc_total_additional_charges(self):
        self.total_additional_charges = flt(
            flt(self.total_detention_amount)
            + flt(self.total_loading_unloading)
            + flt(self.weighment_charges),
            2,
        )

    # ------------------------------------------------------------------ #
    #  APPROVED CHARGES                                                    #
    # ------------------------------------------------------------------ #

    def _calc_approved_charges(self):
        self.approved_detention_charge = flt(
            flt(self.approved_origin_detention) + flt(self.approved_destination_detention), 2
        )
        self.approved_loading_unloading = flt(
            flt(self.approved_loading_charge) + flt(self.approved_unloading_charge), 2
        )

        total_approved = flt(
            flt(self.approved_detention_charge)
            + flt(self.approved_loading_unloading)
            + flt(self.approved_weighment)
            + flt(self.approved_extra_expenses)
            - flt(self.tds_by_customer),
            2,
        )
        self.total_approved_additional = total_approved

        claimed = flt(self.total_additional_charges)
        self.difference_claimed_approved = flt(claimed - total_approved, 2)

    # ------------------------------------------------------------------ #
    #  TRIP TOTAL                                                          #
    # ------------------------------------------------------------------ #

    def _calc_trip_total(self):
        self.trip_total_amount = flt(
            flt(self.customer_freight) + flt(self.total_approved_additional), 2
        )

    # ------------------------------------------------------------------ #
    #  POD STATUS                                                          #
    # ------------------------------------------------------------------ #

    def _update_pod_status(self):
        if self.pod_upload_date and self.pod_type:
            self.pod_status = "POD Uploaded"
        else:
            self.pod_status = "POD Not Uploaded"

    # ------------------------------------------------------------------ #
    #  TRIP STATUS                                                         #
    # ------------------------------------------------------------------ #

    def _update_trip_status(self):
        """
        Progression:
          Trip Created → In Transit → Awaiting Billing → Billed
          → Payment Received → Closed
        """
        if self.utr_no and self.date_bill_credited:
            self.trip_status = "Payment Received"
        elif self.bill_no and self.bill_date:
            self.trip_status = "Billed"
        elif self.pod_status == "POD Uploaded":
            self.trip_status = "Awaiting Billing"
        elif self.dispatch_date_time and self.arrival_date_time:
            self.trip_status = "In Transit"
        else:
            self.trip_status = "Trip Created"

    # ------------------------------------------------------------------ #
    #  CLOSE TRIP                                                          #
    # ------------------------------------------------------------------ #

    def on_update(self):
        """Mark trip as Closed when payment is received and billed amount matches."""
        if (
            self.trip_status == "Payment Received"
            and self.trip_total_billed
            and self.utr_no
        ):
            frappe.db.set_value("Trip", self.name, "trip_status", "Closed", update_modified=False)

    # ------------------------------------------------------------------ #
    #  VALIDATION GUARDS                                                   #
    # ------------------------------------------------------------------ #

    def validate_dates(self):
        if self.reach_date_time and self.dispatch_date_time:
            if get_datetime(self.dispatch_date_time) < get_datetime(self.reach_date_time):
                frappe.throw(
                    frappe._("Dispatch Date/Time cannot be before Reach Date/Time at Loading Site.")
                )
        if self.arrival_date_time and self.dispatch_date_time:
            if get_datetime(self.arrival_date_time) < get_datetime(self.dispatch_date_time):
                frappe.throw(
                    frappe._("Arrival Date/Time at Unloading Site cannot be before Dispatch Date/Time.")
                )
        if self.release_date_time and self.arrival_date_time:
            if get_datetime(self.release_date_time) < get_datetime(self.arrival_date_time):
                frappe.throw(
                    frappe._("Release Date/Time cannot be before Arrival Date/Time at Unloading Site.")
                )
