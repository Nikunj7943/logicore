import frappe


@frappe.whitelist()
def get_trip_type_theme(company, trip_type=None):
    """
    Returns the color and theme for a given trip_type based on TMS Settings.
    Falls back to the default trip type theme if no match found.
    Company is used to scope settings in the future (currently single doctype).
    """
    try:
        settings = frappe.get_single("TMS Settings")
    except Exception:
        return {}

    if not settings or not settings.trip_type_themes:
        return {}

    themes = settings.trip_type_themes

    # Try to find exact match for trip_type
    if trip_type:
        for row in themes:
            if row.trip_type == trip_type:
                return {"color": row.color, "theme": row.theme}

    # Fallback: row marked as default
    for row in themes:
        if row.is_default:
            return {"color": row.color, "theme": row.theme}

    # Last fallback: first row
    if themes:
        return {"color": themes[0].color, "theme": themes[0].theme}

    return {}


@frappe.whitelist()
def get_tms_settings(company=None):
    """
    Returns TMS Settings for a given company.
    Includes company_code, default_trip_type and trip_type_themes list.
    """
    try:
        settings = frappe.get_single("TMS Settings")
    except Exception:
        return {}

    themes = []
    for row in (settings.trip_type_themes or []):
        themes.append({
            "trip_type": row.trip_type,
            "color": row.color,
            "theme": row.theme,
            "is_default": row.is_default,
        })

    return {
        "company": settings.company,
        "company_code": settings.company_code,
        "default_trip_type": settings.default_trip_type or "Primary Trip",
        "trip_type_themes": themes,
    }
