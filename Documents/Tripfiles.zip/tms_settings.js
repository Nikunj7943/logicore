frappe.ui.form.on('TMS Settings', {
    refresh(frm) {
        frm.set_intro(
            __('Configure company-wise Trip ID prefix and color themes for each Trip Type.'),
            'blue'
        );

        // Preview button: show all trip type colors as swatches
        frm.add_custom_button(__('Preview Theme Colors'), () => {
            if (!frm.doc.trip_type_themes || !frm.doc.trip_type_themes.length) {
                frappe.msgprint(__('No Trip Type themes defined yet.'));
                return;
            }

            let html = `<div style="padding:10px;">`;
            frm.doc.trip_type_themes.forEach(row => {
                const textColor = _isDarkColor(row.color) ? '#fff' : '#333';
                html += `
                    <div style="
                        display:inline-flex; align-items:center; gap:10px;
                        background:${row.color}; color:${textColor};
                        border-radius:6px; padding:8px 16px; margin:6px;
                        font-weight:600; font-size:13px;
                        box-shadow: 0 2px 4px rgba(0,0,0,0.15);
                    ">
                        <span>${row.trip_type}</span>
                        ${row.is_default ? '<span style="font-size:10px;opacity:0.85;">(Default)</span>' : ''}
                        <span style="font-size:11px;opacity:0.75;">${row.theme}</span>
                    </div>`;
            });
            html += `</div>`;

            frappe.msgprint({
                title: __('Trip Type Color Preview'),
                message: html,
                wide: true
            });
        });
    },

    company(frm) {
        if (frm.doc.company && !frm.doc.company_code) {
            // Auto-suggest company code from company abbr
            frappe.db.get_value('Company', frm.doc.company, 'abbr', (r) => {
                if (r && r.abbr) {
                    frm.set_value('company_code', r.abbr.toUpperCase());
                }
            });
        }
    }
});

// Helper: determine if a hex color is dark (for contrast)
function _isDarkColor(hex) {
    if (!hex) return false;
    const c = hex.replace('#', '');
    const r = parseInt(c.substr(0, 2), 16);
    const g = parseInt(c.substr(2, 2), 16);
    const b = parseInt(c.substr(4, 2), 16);
    // Perceived luminance formula
    return (r * 299 + g * 587 + b * 114) / 1000 < 128;
}
